<?php
require(__DIR__ . '/../module/Vendor/Installer/install.php');

