<?php
return trans('modstart::validation');
