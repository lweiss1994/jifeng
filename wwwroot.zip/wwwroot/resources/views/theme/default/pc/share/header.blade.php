<header class="ub-header-b">
    <div class="ub-container">
        <div class="menu">
            @if(\Module\Member\Auth\MemberUser::id())
                @if(!\ModStart\Core\Util\AgentUtil::isMobile())
                    <a href="{{modstart_web_url('credit_shop/cart')}}">
                        <i class="iconfont icon-cart"></i>
                        <?php $count = \Module\CreditShop\Util\CartUtil::getUserCartCount(\Module\Member\Auth\MemberUser::id()); ?>
                        <span class="badge @if(!$count) tw-hidden @endif" data-shop-cart-count>{{$count}}</span>
                    </a>
                @endif
                <a href="{{modstart_web_url('member')}}"><i class="iconfont icon-user"></i> {{\Module\Member\Auth\MemberUser::get('username')}}</a>
                <a href="javascript:;" data-confirm="确认退出？" data-href="/logout">退出</a>
            @else
                <a href="{{modstart_web_url('login')}}">登录</a>
                <a href="{{modstart_web_url('register')}}">注册</a>
            @endif
        </div>
        <div class="logo">
            <a href="{{modstart_web_url('')}}">
                <img src="{{\ModStart\Core\Assets\AssetsUtil::fix(modstart_config('siteLogo'))}}"/>
            </a>
        </div>
        <div class="nav-mask" onclick="$(this).closest('.ub-header-b').removeClass('show')"></div>
        <div class="nav">
            @foreach(\Module\Nav\Util\NavUtil::listByPositionWithCache('head') as $nav)
                <a class="{{modstart_baseurl_active($nav['link'])}}" href="{{$nav['link']}}" {{\Module\Nav\Type\NavOpenType::getBlankAttributeFromValue(empty($nav['openType'])?null:$nav['openType'])}}>{{$nav['name']}}</a>
            @endforeach
        </div>
        <a class="nav-toggle" href="javascript:;" onclick="$(this).closest('.ub-header-b').toggleClass('show')">
            <i class="show iconfont icon-list"></i>
            <i class="close iconfont icon-close"></i>
        </a>
    </div>
</header>
