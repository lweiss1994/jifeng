@extends('modstart::app.web.dialogFrame')

@section('bodyContent')
    {!! $content or '' !!}
@endsection
