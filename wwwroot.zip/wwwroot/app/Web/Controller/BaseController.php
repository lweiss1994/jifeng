<?php
 namespace App\Web\Controller; use Illuminate\Routing\Controller; use ModStart\Core\View\ResponsiveViewTrait; class BaseController extends Controller { use ResponsiveViewTrait; } 