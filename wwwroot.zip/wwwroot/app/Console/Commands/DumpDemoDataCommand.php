<?php
 namespace App\Console\Commands; use Module\Vendor\Command\BaseDumpDemoDataCommand; class DumpDemoDataCommand extends BaseDumpDemoDataCommand { public function handle() { } } 