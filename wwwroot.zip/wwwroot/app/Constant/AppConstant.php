<?php
 namespace App\Constant; class AppConstant { const APP = 'mzjifen'; const VERSION = '1.5.0'; } 