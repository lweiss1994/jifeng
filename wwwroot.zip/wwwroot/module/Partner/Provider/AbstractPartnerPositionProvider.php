<?php
 namespace Module\Partner\Provider; abstract class AbstractPartnerPositionProvider { abstract public function name(); abstract public function title(); } 