<?php
 namespace Module\Nav\Biz; abstract class AbstractNavPositionBiz { abstract public function name(); abstract public function title(); } 