<?php
 $router->match(['get', 'post'], 'site/config/setting', 'ConfigController@setting'); 