<?php
 namespace Module\Member\Provider\RegisterProcessor; use Module\Vendor\Provider\ProviderTrait; class MemberRegisterProcessorProvider { use ProviderTrait; } 