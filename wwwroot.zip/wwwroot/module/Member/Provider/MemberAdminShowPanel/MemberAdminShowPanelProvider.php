<?php
 namespace Module\Member\Provider\MemberAdminShowPanel; use Module\Vendor\Provider\ProviderTrait; class MemberAdminShowPanelProvider { use ProviderTrait; } 