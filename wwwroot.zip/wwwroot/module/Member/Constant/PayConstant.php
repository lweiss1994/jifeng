<?php
 namespace Module\Member\Constant; class PayConstant { const MEMBER_VIP = 'mMemberVip'; }