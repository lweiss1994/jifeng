<?php
 namespace Module\Member\Support; interface MemberLoginCheck { } 