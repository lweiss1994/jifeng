<?php
 namespace Module\Banner\Provider; abstract class AbstractBannerPositionProvider { abstract public function name(); abstract public function title(); } 