<?php
 $router->match(['get', 'post'], 'banner/get', 'BannerController@get'); 