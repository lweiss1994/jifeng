<?php return array (
  'system' => 
  array (
    'Vendor' => 
    array (
      'enable' => true,
    ),
    'AdminManager' => 
    array (
      'enable' => true,
    ),
    'ModuleStore' => 
    array (
      'enable' => true,
    ),
    'Site' => 
    array (
      'enable' => true,
    ),
    'Article' => 
    array (
      'enable' => true,
      'config' => 
      array (
        'position' => '[{"k":"","v":"单页"},{"k":"simple","v":"简单页面"}]',
      ),
    ),
    'Nav' => 
    array (
      'enable' => true,
      'config' => 
      array (
        'position' => '[{"k":"head","v":"头部导航"},{"k":"foot","v":"底部导航"}]',
      ),
    ),
    'Banner' => 
    array (
      'enable' => true,
    ),
    'Partner' => 
    array (
      'enable' => true,
    ),
    'Member' => 
    array (
      'enable' => true,
      'config' => 
      array (
        'addressEnable' => true,
        'creditEnable' => true,
      ),
    ),
    'Tecmz' => 
    array (
      'enable' => true,
    ),
  ),
);